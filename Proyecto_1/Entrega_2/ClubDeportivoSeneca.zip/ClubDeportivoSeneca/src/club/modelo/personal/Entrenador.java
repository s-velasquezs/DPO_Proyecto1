package club.modelo.personal;

public class Entrenador extends Empleado{

	public Entrenador(String username, String password, String nombre) {
		super(username, password, nombre);
		// TODO Auto-generated constructor stub
	}

}
