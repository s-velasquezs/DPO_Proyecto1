package club.modelo.personal;

import club.modelo.salud.HistorialMedico;
import club.modelo.usuarios.Jugador;

public class Fisioterapeuta extends Empleado {

    public Fisioterapeuta(String username, String password, String nombre) {
        super(username, password, nombre);
    }

    public boolean registrarLesion(Jugador jugador, String descripcion) {
        if (jugador == null) {
            return false;
        }
        return jugador.getHistorialMedico().registrarLesion(descripcion);
    }

    public boolean darAlta(Jugador jugador) {
        if (jugador == null) {
            return false;
        }
        return jugador.getHistorialMedico().darAlta("Alta medica");
    }

    public HistorialMedico consultarHistorial(Jugador jugador) {
        if (jugador == null) {
            return null;
        }
        return jugador.getHistorialMedico();
    }

    public void editarHistorial(Jugador jugador, String cambios) {
        if (jugador != null) {
            jugador.getHistorialMedico().agregarObservacion(cambios);
        }
    }
}