package club.modelo.personal;

import java.time.LocalDate;
import java.time.LocalTime;

public class Turno {
	
	private Empleado empleado;
	private LocalDate fecha;
	private LocalTime horaInicio;
	private LocalTime horaFin;
	
	
	public Turno(Empleado empleado, LocalDate fecha, LocalTime horaInicio, LocalTime horaFin) {
		super();
		this.empleado = empleado;
		this.fecha = fecha;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
	}




	public boolean seSobrepone(LocalTime otraHoraInicio, LocalTime otraHoraFin) {
	    return horaInicio.isBefore(otraHoraFin) && otraHoraInicio.isBefore(horaFin);
	}

	public boolean seSobrepone(LocalDate fechaTurno, LocalTime otraHoraInicio, LocalTime otraHoraFin) {
	    return fecha.equals(fechaTurno) && seSobrepone(otraHoraInicio, otraHoraFin);
	}



	public Empleado getEmpleado() {
		return empleado;
	}




	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}




	public LocalDate getFecha() {
		return fecha;
	}




	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}




	public LocalTime getHoraInicio() {
		return horaInicio;
	}




	public void setHoraInicio(LocalTime horaInicio) {
		this.horaInicio = horaInicio;
	}




	public LocalTime getHoraFin() {
		return horaFin;
	}




	public void setHoraFin(LocalTime horaFin) {
		this.horaFin = horaFin;
	}
	@Override
	public String toString() {
	    return fecha + " " + horaInicio + "-" + horaFin;
	}
	
	
}