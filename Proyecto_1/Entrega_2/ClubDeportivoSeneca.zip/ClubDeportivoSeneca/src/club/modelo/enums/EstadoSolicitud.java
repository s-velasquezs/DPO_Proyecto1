package club.modelo.enums;

public enum EstadoSolicitud {
	PENDIENTE,
	APROBADA,
	RECHAZADA;

}
