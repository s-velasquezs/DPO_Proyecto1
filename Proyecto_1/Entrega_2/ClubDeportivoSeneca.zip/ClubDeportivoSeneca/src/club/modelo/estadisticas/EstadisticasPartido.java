package club.modelo.estadisticas;

import club.modelo.partidos.Partido;
import club.modelo.usuarios.Jugador;

public class EstadisticasPartido extends Estadisticas{
	
	private Partido partido;
	private Jugador jugador;
	private int minutos;
	
	public Partido getPartido() {
		return partido;
	}
	public void setPartido(Partido partido) {
		this.partido = partido;
	}
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}
	public int getMinutos() {
		return minutos;
	}
	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}
	
	
	

}
