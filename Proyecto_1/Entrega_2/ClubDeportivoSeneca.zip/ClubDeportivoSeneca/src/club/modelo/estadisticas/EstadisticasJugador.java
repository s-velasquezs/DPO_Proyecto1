package club.modelo.estadisticas;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class EstadisticasJugador extends Estadisticas {

    private List<String> sanciones = new ArrayList<>();
    private int partidosSuspension = 0;
    private int amarillasSancionadas = 0;

    public List<String> getSanciones() {
        return sanciones;
    }
    
    public void acumular(Estadisticas estadisticas) {
        sumar(estadisticas.getValores());


        int ciclos = get("amarillas") / 2;
        while (amarillasSancionadas < ciclos) {
            aplicarSancion("Acumulacion de amarillas", 1);
            amarillasSancionadas++;
        }

        for (int i = 0; i < estadisticas.get("rojas"); i++) {
            aplicarSancion("Roja directa", 1);
        }
    }

    public int getPartidosSuspension() {
        return partidosSuspension;
    }


    public void aplicarSancion(String motivo, int partidos) {
        sanciones.add(motivo);
        partidosSuspension += partidos;
    }

    public void consumirSuspension() {
        if (partidosSuspension > 0) {
            partidosSuspension--;
        }
    }

    public boolean tieneSancionActiva() {
        return partidosSuspension > 0;
    }

    private void sumar(Map<String, Integer> otros) {
        for (Map.Entry<String, Integer> e : otros.entrySet()) {
            registrar(e.getKey(), get(e.getKey()) + e.getValue());
        }
    }
}