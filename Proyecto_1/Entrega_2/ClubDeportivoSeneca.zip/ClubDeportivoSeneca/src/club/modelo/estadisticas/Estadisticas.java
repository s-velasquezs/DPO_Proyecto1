package club.modelo.estadisticas;

import java.util.HashMap;
import java.util.Map;

public abstract class Estadisticas {
	
	private Map<String,Integer> valores = new HashMap<>();
	
	public void registrar(String razon, int valor) {
		this.valores.put(razon, valor);
	}
	
    public Map<String, Integer> getValores() {
        return valores;
    }
	
    public int get(String razon) {
        return valores.getOrDefault(razon, 0);
    }

 
}
