package club.modelo.comercio;

import club.modelo.usuarios.Usuario;

public class ProgramaFidelidad {
	
	private Usuario propietario;
	private int saldoPuntos;
	public ProgramaFidelidad(Usuario propietario, int saldoPuntos) {
		super();
		this.propietario = propietario;
		this.saldoPuntos = saldoPuntos;
	}
	
	// Cosas raras con venta 
	
	
	
	

}
