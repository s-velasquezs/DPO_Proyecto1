package club.modelo.usuarios;

public class RankingELO {
	private InscripcionIndividual inscripcion;
	private int puntaje;
	private int partidosJugados;
	
	public void actualizar(RankingELO rival, boolean gano) {
	    double esperado = 1.0 / (1 + Math.pow(10, (rival.puntaje - puntaje) / 400.0));
	    double resultado;
	    if (gano) {
	        resultado = 1;
	    } else {
	        resultado = 0;
	    }

	    puntaje = puntaje + (int) Math.round(32 * (resultado - esperado));
	    partidosJugados++;
	}
	
	public int getPuntaje() {
		return puntaje;
	}
	
	public boolean tieneRanking() {
		return partidosJugados > 0;
	}

	public RankingELO(InscripcionIndividual inscripcion, int puntaje, int partidosJugados) {
		
		this.inscripcion = inscripcion;
		this.puntaje = puntaje;
		this.partidosJugados = partidosJugados;
	}
	
	public RankingELO(InscripcionIndividual inscripcion) {

		this.inscripcion = inscripcion;
        this.puntaje = 1000;
        this.partidosJugados = 0;

	}
	
	
}
