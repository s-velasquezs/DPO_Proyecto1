package club.modelo.usuarios;

import java.time.LocalDate;

import club.modelo.deportes.DeporteIndividual;
import club.modelo.enums.Nivel;

public class InscripcionIndividual {
	
	private Jugador jugadorIndividual;
	private DeporteIndividual deporte;
	private Nivel nivel;
	private LocalDate fechaInscripcion;
	private RankingELO rankingELO;
	private boolean activa;
	
	public InscripcionIndividual(Jugador jugadorIndividual, DeporteIndividual deporte, Nivel nivel,
			LocalDate fechaInscripcion, RankingELO rankingELO, boolean activa) {
		super();
		this.jugadorIndividual = jugadorIndividual;
		this.deporte = deporte;
		this.nivel = nivel;
		this.fechaInscripcion = fechaInscripcion;
		this.rankingELO = rankingELO;
		this.activa = activa;
	}
	
	public InscripcionIndividual(Jugador jugadorIndividual, DeporteIndividual deporte, Nivel nivel) {
	    this.jugadorIndividual = jugadorIndividual;
	    this.deporte = deporte;
	    this.nivel = nivel;
	    this.fechaInscripcion = LocalDate.now();
	    this.activa = true;
	    this.rankingELO = new RankingELO(this);
	}
	
	

	public void cambiarNivel(Nivel nuevoNivel) {
		this.nivel = nuevoNivel;
	}
	
	public void darDeBaja() {
		this.activa = false;
	}
	
	public boolean estaActiva() {
		return activa;
	}

	public Jugador getJugadorIndividual() {
		return jugadorIndividual;
	}

	public void setJugadorIndividual(Jugador jugadorIndividual) {
		this.jugadorIndividual = jugadorIndividual;
	}

	public DeporteIndividual getDeporte() {
		return deporte;
	}

	public void setDeporte(DeporteIndividual deporte) {
		this.deporte = deporte;
	}

	public Nivel getNivel() {
		return nivel;
	}

	public void setNivel(Nivel nivel) {
		this.nivel = nivel;
	}

	public LocalDate getFechaInscripcion() {
		return fechaInscripcion;
	}

	public void setFechaInscripcion(LocalDate fechaInscripcion) {
		this.fechaInscripcion = fechaInscripcion;
	}

	public RankingELO getRankingELO() {
		return rankingELO;
	}

	public void setRankingELO(RankingELO rankingELO) {
		this.rankingELO = rankingELO;
	}

	public boolean isActiva() {
		return activa;
	}

	public void setActiva(boolean activa) {
		this.activa = activa;
	}
	
	

}
